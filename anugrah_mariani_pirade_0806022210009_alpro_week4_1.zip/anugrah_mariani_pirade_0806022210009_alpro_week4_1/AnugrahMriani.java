
package anugrah_mariani_pirade_0806022210009_alpro_no4;


public class Anugrah_mariani_pirade_0806022210009_alpro_no4 {
    
    public static void main(String[] args) {
        double Gaji, gajikotor, pajak, gajibersih, kerja;
        
        Gaji= 6;
        kerja= 37;
       
        gajikotor= (6*37);
        System.out.println("Gajikotor:"+gajikotor);
        
        pajak=(gajikotor*0.1);
        System.out.println("Pajak:"+pajak);
        
        gajibersih=(gajikotor-pajak);
        System.out.println("Gajibersih:"+gajibersih);
        
        
        
        
        
        
        
    }
    
}
