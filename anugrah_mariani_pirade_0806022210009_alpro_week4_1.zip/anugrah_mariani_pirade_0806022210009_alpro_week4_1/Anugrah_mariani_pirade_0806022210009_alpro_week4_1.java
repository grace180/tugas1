
package anugrah_mariani_pirade_0806022210009_alpro_week4_1;

public class Anugrah_mariani_pirade_0806022210009_alpro_week4_1 {

    public static void main(String[] args) {
     int 
     nilai=90;
    
     if(nilai>75){
        System.out.println("lulus");
        }
         else 
         System.out.println("tidak lulus");
    }
}  
    

