/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package anugrah_mariani_pirade_0806022210009_alpro_week4_1;

/**
 *
 * @author Lenovo
 */
class masukkan {
    
}
